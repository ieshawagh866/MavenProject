package MavenProject;

//import static org.junit.Assert.*;
//
//import org.junit.Test;
//
//public class SimpleRegression1Test {
//
//	@Test
//	public void test() {
//		fail("Not yet implemented");
//	}
//
//}
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.math3.stat.regression.SimpleRegression;
import org.junit.jupiter.api.Test;

class SimpleRegresssion1Test {

    @Test
    void testGetValue() {
        SimpleRegression1 regressionObj = new SimpleRegression1();

        int[] xValues = {1, 2, 3, 4, 5};
        int[] yValues = {2, 4, 6, 8, 10}; // y = 2x

        // Expected slope using Apache Commons Math
        SimpleRegression regression = new SimpleRegression();
        for (int i = 0; i < xValues.length; i++) {
            regression.addData(xValues[i], yValues[i]);
        }
        double expectedSlope = regression.getSlope();
        expectedSlope = Math.round(expectedSlope * 100.0) / 100.0;


        // Get actual slope from our method
        double actualSlope = regressionObj.getValue(xValues, yValues);
        
        System.out.println("Expected Slope: " + expectedSlope);
        System.out.println("Actual Slope: " + actualSlope);

        // Compare expected vs actual with tolerance
        assertEquals(expectedSlope, actualSlope, 1e-6, "Slope calculation is incorrect");

    }
}

