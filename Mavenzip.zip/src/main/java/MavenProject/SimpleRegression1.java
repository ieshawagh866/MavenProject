package MavenProject;

public class SimpleRegression1 {

	public double getValue(int[] xValues, int[] yValues) {

		// create an array

		double slp=0;

		// getting array length

		int lengthX = xValues.length;

		int lengthY = yValues.length;

		if (lengthX == lengthY) {

			// default sum value.

			int sumX = 0, sumY = 0;

			double[] diffX = new double[lengthX], diffY
					= new double[lengthY], prodXY = new double[lengthX], sqX =
					new double[lengthX];

			double sumProd = 0, sumSq = 0;

			// sum of all values in array using for loop

			for (int i = 0; i < lengthX; i++) {

				sumX += xValues[i];

				sumY += yValues[i];

			}
			double averageX = (double) sumX / lengthX;  
			double averageY = (double) sumY / lengthY;


			for (int i = 0; i < lengthX; i++) {

				diffX[i] = xValues[i]-averageX;

				diffY[i] = yValues[i]-averageY;

				prodXY[i] = diffX[i] * diffY[i];  
				sqX[i] = diffX[i] * diffX[i];      

				sumProd += prodXY[i];

				sumSq += sqX[i];

			}

			slp = sumProd/sumSq;
			 slp = Math.round(slp * 100.0) / 100.0;

			System.out.println("slope : "+ slp);

		}

		return(slp);

	}
}



